<!DOCTYPE html> 
<html>
<head>
	<title>Ujian</title>
	<link rel="stylesheet" type="text/css" href="style_soal.css">
</head>
<body>
	<?php 
		$koneksi = mysqli_connect('localhost','root','','smart');

		$perpage = 5;
		$page    = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
		$start   = ($page>1) ? ($page * $perpage) -  $perpage : 0;

		$soal    = "SELECT * FROM soal LIMIT $start, $perpage";
		$result  = mysqli_query($koneksi,$soal);

		$query   = "SELECT * FROM soal";
		$sql = mysqli_query($koneksi,$query);
		$cek = mysqli_num_rows($sql);

		$pages = ceil($start/$perpage);

		$i=0;
		while ($data=mysqli_fetch_assoc($result)) {
		$i++;
	 ?>
	
	<form action="proses_jawab.php" method="get">
		
			<div id="soal">
			
				<p><?php echo $i; ?>.<?php echo $data['soal']; ?></p>

				<label>a</label>
				<input type="radio" name="pilihan[<?php echo $data['id']; ?>]" value="a">
				<label><?php echo $data['a'] ?></label><br>

				<label>b</label>
				<input type="radio" name="pilihan[<?php echo $data['id']; ?>]" value="b">
				<label><?php echo $data['b']; ?></label><br>

				<label>c</label>
				<input type="radio" name="pilihan[<?php echo $data['id']; ?>]" value="c">
				<label><?php echo $data['c']; ?></label><br>

				<label>d</label>
				<input type="radio" name="pilihan[<?php echo $data['id']; ?>]" value="d">
				<label><?php echo $data['d']; ?></label><br>

			</div>

	<?php } ?>

	<?php for ($i=1 ; $i < $perpage ; $i++) { ?>
		<a href="?halaman=<?php echo $i; ?>"><?php echo $i; ?></a>
	<?php } ?>
	<input type="submit" name="submit" value="" onclick="return confirm('Apakah Anda Yakin')" class="tombol">

	</form>
	<div>
		
	</div>
</body>
</html>