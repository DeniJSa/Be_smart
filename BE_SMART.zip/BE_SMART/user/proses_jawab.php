<?php 
	$koneksi = mysqli_connect('localhost','root','','smart');
// 	if (isset($_POST['submit'])) {
// 		$jawab = 0;
// 		$salah = 0;
// 		$jwb   = $_POST['pilihan'];
// 		$query = "SELECT * FROM soal WHERE  knc_jwb='$jwb'";
// 		$sql   = mysqli_query($koneksi,$query);
// 		$cek   = mysqli_num_rows($query);
// 		if ($cek ) {
// 			$jawab++;
// 		}else{
// 			$salah++;
// 		}

	
// echo "
//          <tr><td>Jumlah Jawaban Benar</td><td> : $jawab </td></tr>
//          <tr><td>Jumlah Jawaban Salah</td><td> : $salah</td></tr>
//          ";
// }

	$get = $_GET["pilihan"];
	echo $get[0];
	echo $get[1];

	$cek = "INSERT "
 ?>
