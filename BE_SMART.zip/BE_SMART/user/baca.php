<!DOCTYPE html>
<html>
<head>
	<title>Belajar</title>
	<link rel="stylesheet" type="text/css" href="style_baca.css">
</head>
<body>
		<a href="../index.php"><img src="../icon/home.png" width="40px"></a>
	  	<form action="" method="post" id="cari">
			<input type="text" name="key" placeholder="masukan keyword.." size="30" autofocus autocomplete="off" class="cari">
			<input type="submit" name="keyword" value="cari" class="tombol">
		</form>
		<br>
	  <div id="bungkus"><?php 
		$koneksi= mysqli_connect('localhost','root','','smart');
		$query= 'SELECT * FROM kimia';
		if (isset($_POST['keyword'])) {
		$key = $_POST['key'];
		$query = "SELECT * FROM kimia WHERE judul LIKE '%$key%' OR materi LIKE '%$key%'";
		}
		$sql  = mysqli_query($koneksi,$query);
		$row  = mysqli_num_rows($sql);
		if ($row > 0) {
			while ( $data = mysqli_fetch_array($sql)) {
	 	
	  ?>
	  		<div class="isi">

		  		<a href="materi.php?no=<?php echo $data['no']; ?>">
		  			<h1>
		  				<?php echo substr($data['judul'], 0,10);
		  			      echo "..."; ?>
		  			</h1>
		  		</a>

		  		<img src="../img/<?php echo $data['gambar'];?>">
		  		<p>
		  			<?php echo substr($data['materi'], 0,30);
		  			     echo "..."; ?>
		  		</p>

	  		</div>

	  <?php 
			}
	  		}else{
	  ?> 
	  			<h1 id="data">data belum ada</h1>
	  <?php } ?> 
		
	  </div>
	  

</body>
</html>