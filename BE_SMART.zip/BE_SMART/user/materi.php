
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style_baca.css">
</head>
<body>
	
	<div id="baca">
		<?php 
			$koneksi = mysqli_connect('localhost','root','','smart');
			$no      = $_GET['no'];
			$sql     = "SELECT * FROM kimia WHERE no='$no'";
			$query   = mysqli_query($koneksi,$sql);
			while ($data=mysqli_fetch_assoc($query)) {
		
	
 		?>
 		<h1 class="judul"><?php echo $data['judul']; ?></h1>
 		<img src="../img/<?php echo $data['gambar']; ?>" width='500px' class='gambar'>
 		<p class="materi"><?php echo $data['materi']; ?></p>
 		<?php } ?>
	</div>
</body>
</html>