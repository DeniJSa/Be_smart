<!DOCTYPE html>
<html>
<head>
	<title>BE_SMART</title>
	<link rel="shortcut icon" href="icon/icon.png">
	<link rel="stylesheet" type="text/css" href="user/style_u.css">
</head>
<body>

	<div id="header">
		<h1>BE-SMART</h1>
		<a href="admin/login_admin.php">ADMIN</a>
	</div>

	<div id="isi">
		<div id="baca">
			<a href="user/baca.php">
				<img src="icon/book.png">
				BELAJAR
				
			</a>
		</div>

		<div id="ujian">
			<a href="user/ujian.php">
				<img src="icon/document.png">
				Ujian
			</a>
		</div>

		<div id="about">
			<a href="user/tentang.php">
				<img src="icon/about.png">
				About
			</a>
		</div>
	</div>

	<div id="footer"><p>copyRight Deni Juli Setiawan</p></div>

</body>
</html>