<?php 
		$id      = $_GET['id'];	
		$koneksi = mysqli_connect('localhost','root','','Smart');
		$query   = "SELECT * FROM soal WHERE id='$id'";
		$sql     = mysqli_query($koneksi,$query);
		$data = mysqli_fetch_assoc($sql)		

?>
<!DOCTYPE html>
<html>
<head>
	<title>soal</title>
	<link rel="stylesheet" type="text/css" href="Style_a.css">
</head>
<body>

	<div id="header">
		<a href="logout.php">logout</a>
	</div>

	<div id="menu">
			<ul class="ul">
				<li class="menu">
					<a href="index_admin.php">Admin</a>
				</li>
				<li class="menu">
					<a href="soal_admin.php"> Buat Soal</a>
				</li>
				<li class="menu">
					<a href="ubah_soal.php"> update Soal</a>
				</li>
				<li class="menu">
					<a href="materi_admin.php"> Materi</a>
				</li>
				<li class="menu">
					<a href="ubah_materi.php"> Update materi</a>
				</li>
			</ul>
	</div>
	
	<div id="soal">
		<form action="proses_ubso.php?id=<?php echo $data['id']; ?>" method="post" >
			<div class="tabel">
				<textarea type="text" name="soal" ><?php echo $data['soal']; ?></textarea><br>
			</div>

			<div class="tabel">
				<input type="text" name="a" value="<?php echo $data['a']; ?>"><br>
			</div>
			
			<div class="tabel">
				<input type="text" name="b" value="<?php echo $data['b']; ?>"><br>
			</div>
				
			<div class="tabel">
				<input type="text" name="c" value="<?php echo $data['c']; ?>"><br>
			</div>	
			
			<div class="tabel">
				<input type="text" name="d" value="<?php echo $data['d']; ?>"><br>
			</div>	
			
			<div class="tabel">
				<input type="text" name="jwb" value="<?php echo $data['knc_jwb']; ?>"><br>
			</div>

			<div class="tombol">
				<input type="submit" name="submit" value="masukan">
			</div>
		</form>
	</div>

</body>
</html>