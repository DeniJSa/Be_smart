<?php 
$id = $_GET['id'];
$koneksi= mysqli_connect("localhost","root","","smart");
$hapus="DELETE FROM soal where id = $id";
	mysqli_query($koneksi,$hapus);


if ($hapus) {
	echo "
				<script>
					alert('data beerhasil dihapus');
					document.location.href='ubah_soal.php';
				</script>
			";
}else{
	echo "
				<script>
					alert('data gagal dihapus');
					document.location.href='ubah_soal.php';
				</script>
			";
}

 ?>