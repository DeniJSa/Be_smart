<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="Style_a.css">
</head>
<body>
	
	
	<div id="menu">
			<ul class="ul">
				<li class="menu">
					<a href="index_admin.php">Admin</a>
				</li>
				<li class="menu">
					<a href="soal_admin.php"> Buat Soal</a>
				</li>
				<li class="menu">
					<a href="ubah_soal.php"> update Soal</a>
				</li>
				<li class="menu">
					<a href="materi_admin.php"> Materi</a>
				</li>
				<li class="menu">
					<a href="ubah_materi.php"> Update materi </a>
				</li>
			</ul>
	</div>

	<div id="header">
		<a href="logout.php">logout</a>
	</div>

	

	<div id="form">
		<table border="1px" id="tabel">
			<tr > 
				<td id="tr">NO</td>
				<td id="tr">JUDUL</td>
				<td id="tr">GAMBAR</td>
				<td id="tr">ARTIKEL</td>
				<td id="tr">AKSI</td>
			</tr>
<?php 
		$i=0;
		$koneksi = mysqli_connect('localhost','root','','Smart');
		$query   = "SELECT * FROM kimia";
		$sql     = mysqli_query($koneksi,$query);
		while ($data = mysqli_fetch_assoc($sql)) {
		$i++;
		

	 ?>

			<tr>
				<td> <?php echo $i;               ?></td>
				<td> <?php echo $data['judul'];	  ?></td>
				<td> <img src="../img/<?php echo $data['gambar']; ?>" width="50px"></td>
				<td> <?php echo substr($data['materi'], 0,20);
						   echo "..."; ?></td>
				<td>
					<a href="form_ubah_materi.php?no=<?php echo $data['no']; ?>">Ubah</a> |
					<a href="proses_hama.php?no=<?php echo $data['no']; ?>" onclick="return confirm('data akan dihapus')">Hapus</a>
				</td>
			</tr>
	<?php } ?>
		</table>
		</div>

</body>
</html>