<?php 
$no = $_GET['no'];
$koneksi= mysqli_connect("localhost","root","","smart");
$hapus="DELETE FROM kimia where no = $no";
	mysqli_query($koneksi,$hapus);


if ($hapus) { 
	echo "
				<script>
					alert('data beerhasil dihapus');
					document.location.href='ubah_materi.php';
				</script>
			";
}else{
	echo "
				<script>
					alert('data gagal dihapus');
					document.location.href='ubah_materi.php';
				</script>
			";
}

 ?>