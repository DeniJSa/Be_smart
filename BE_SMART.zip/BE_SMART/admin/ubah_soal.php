<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="Style_a.css">
</head>
<body>

	<div id="menu">
			<ul class="ul">
				<li class="menu">
					<a href="index_admin.php">Admin</a>
				</li>
				<li class="menu">
					<a href="soal_admin.php"> Buat Soal</a>
				</li>
				<li class="menu">
					<a href="ubah_soal.php"> update Soal</a>
				</li>
				<li class="menu">
					<a href="materi_admin.php"> Materi</a>
				</li>
				<li class="menu">
					<a href="ubah_materi.php"> Update materi </a>
				</li>
			</ul>
	</div>

	<div id="header">
		<a href="logout.php">logout</a>
	</div>

	

	<div id="form">
		<table border="1px" id="tabell">
			<tr >
				<td id="tr">NO</td>
				<td id="tr">SOAL</td>
				<td id="tr">A</td>
				<td id="tr">B</td>
				<td id="tr">C</td>
				<td id="tr">D</td>
				<td id="tr">JAWABAN</td>
				<td id="tr">AKSI</td>
			</tr>
<?php 
		$i=0;
		$koneksi = mysqli_connect('localhost','root','','Smart');
		$query   = "SELECT * FROM soal";
		$sql     = mysqli_query($koneksi,$query);
		while ($data = mysqli_fetch_assoc($sql)) {
		$i++;	
		

	 ?>

			<tr>
				<td> <?php echo $i;               ?></td>
				<td> <?php echo $data['soal'];	  ?></td>
				<td> <?php echo $data['a']   ;    ?></td>
				<td> <?php echo $data['b']   ;	  ?></td>
				<td> <?php echo $data['c']   ;    ?></td>
				<td> <?php echo $data['d']   ;    ?></td>
				<td> <?php echo $data['knc_jwb']; ?></td>
				<td>
					<a href="form_ubah_soal.php?id=<?php echo $data['id']; ?>">Ubah</a> |
					<a href="proses_haso.php?id=<?php echo $data['id']; ?>" onclick="return confirm('yakin data akan dihapus')">Hapus</a>
				</td>
			</tr>
	<?php } ?>
		</table>
		</div>

</body>
</html> 