<?php 

	$koneksi= mysqli_connect('localhost','root','','smart');
	if (isset($_POST['submit'])) {
		$var1  = htmlspecialchars($_POST['judul']);

		$var2  = $_FILES['gambar']['name'];
		$tmp   = $_FILES['gambar']['tmp_name'];
		$pecah = explode('.', $var2);
		$type  = end($pecah);
		$namabaru =uniqid();
		$namabaru.='.';
		$namabaru.= $type;

		$var3  = htmlspecialchars($_POST['materi']);

		move_uploaded_file($tmp,"../img/".$namabaru);
		$query = "INSERT INTO kimia VALUES(NULL,'$var1','$namabaru','$var3')";
		mysqli_query($koneksi,$query);
		if (mysqli_affected_rows($koneksi)) {
			echo "
					<script>
						alert('DATA BERHASIL DITAMBAH');
						document.location.href='materi_admin.php';
					</script>";
		}else{
			echo "
					<script>
						alert('DATA GAGAL DITAMBAH');
						document.location.href='materi_admin.php';
					</script>";
		}
	}
 ?>