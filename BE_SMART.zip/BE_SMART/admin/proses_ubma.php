<?php 
	$koneksi = mysqli_connect('localhost','root','','smart');

	if (isset($_POST['submit'])) {
		$no         = htmlspecialchars($_GET['no']);
		$judul      = htmlspecialchars($_POST['judul']);
		$materi     = $_POST['materi'];
		$gambarlama = $_POST['gambarlama'];

		if ($_FILES['gambar']['error'] == 4) {
			$gambar = $gambarlama;
		}else{
			$var2     = $_FILES['gambar']['name'];
			$tmp      = $_FILES['gambar']['tmp_name'];
			$pecah    = explode('.', $var2);
			$type     = end($pecah);
			$gambar   = uniqid();
			$gambar  .= '.';
			$gambar  .= $type;
			move_uploaded_file($tmp,"../img/".$gambar);
		}

		$sql    = "UPDATE kimia SET judul = '$judul', gambar='$gambar', materi = '$materi' WHERE no='$no'";
		$query  = mysqli_query($koneksi,$sql);
		if ($sql) {
			echo "
				<script>
					alert('data berhasil diubah');
					document.location.href='ubah_materi.php';
				</script>

			";
		}else{
			echo "
				<script>
					alert('data gagal diubah');
					document.location.href='ubah_materi.php';
				</script>

			";
		}
	}

 ?>