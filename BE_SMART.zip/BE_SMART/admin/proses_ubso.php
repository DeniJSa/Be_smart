<?php 
	$koneksi= mysqli_connect('localhost','root','','smart');
	$id     = $_GET['id'];
	if (isset($_POST['submit'])) {
		$soal	= htmlspecialchars($_POST['soal']);
		$a   	= htmlspecialchars($_POST['a']);
		$b   	= htmlspecialchars($_POST['b']);
		$c   	= htmlspecialchars($_POST['c']);
		$d   	= htmlspecialchars($_POST['d']);
		$jwb 	= htmlspecialchars($_POST['jwb']);

		
		$query="UPDATE soal SET soal='$soal', a='$a', b='b', c='$c', d='$d', knc_jwb='$jwb' WHERE id='$id'";
		mysqli_query($koneksi,$query);
		if (mysqli_affected_rows($koneksi)) {
			echo "
					<script>
						alert('DATA BERHASIL DIUBAH');
						document.location.href='ubah_soal.php';
					</script>
				";
		}else{
			echo "
					<script>
						alert('DATA GAGAL DIUBAH');
						document.location.href='soal_admin.php';
					</script>
				";
		}

	}
?>