<?php 
		$no      = $_GET['no'];	
		$koneksi = mysqli_connect('localhost','root','','Smart');
		$query   = "SELECT * FROM kimia WHERE no='$no'";
		$sql     = mysqli_query($koneksi,$query);
		$data = mysqli_fetch_assoc($sql)		

?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="Style_a.css">
</head>
<body>
	<div id="menu">
			<ul class="ul">
				<li class="menu">
					<a href="index_admin.php">Admin</a>
				</li>
				<li class="menu">
					<a href="soal_admin.php"> Buat Soal</a>
				</li>
				<li class="menu">
					<a href="ubah_soal.php"> update Soal</a>
				</li>
				<li class="menu">
					<a href="materi_admin.php"> Materi</a>
				</li>
				<li class="menu">
					<a href="ubah_materi.php"> Update materi </a>
				</li>
			</ul>
	</div>
	<div id="header">
		<a href="logout.php">logout</a>
		
	</div>

	<div id="form">
			<form action="proses_ubma.php?no=<?= $data['no'] ?>" method="post" enctype="multipart/form-data" class="input">
				<input type="hidden" name="gambarlama" value=" <?php echo $data['gambar']; ?> ">

				<div class="tabel">
					<input type="text" name="judul" value="<?php echo $data['judul'] ?>" class="inp"><br>
				</div>
				<div class="tabel">
					<img src="../img/<?php echo $data['gambar']; ?>" width="40px">
					<input type="file" name="gambar" class="put"><br>
				</div>
				<div class="tabel">
					<textarea type="text" name="materi" class="in"><?php echo $data['materi']; ?></textarea><br>
				</div>
				<div class="tombol">
					<input type="submit" name="submit" value="masukan" class="in">
				</div>	

				
			</form>
		</div>

</body>
</html>