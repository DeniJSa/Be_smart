<?php 
//isset untuk mengecek
	if (isset($_COOKIE['login'])) {
		if ($_COOKIE['login'] == 'true') {
		$_SESSION['admi'] = true;

	}
	}
	session_start();
	if (isset($_SESSION['admi'])) {
		header("location:index_admin.php");
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<link rel="stylesheet" type="text/css" href="Style_a.css">
</head>
<body>
	<div id="body">
	<div id="login">
		<h3>Masukan User Name & Password</h3>
		<form action="proses_login.php" method="post">
			<div class="masuk">
				<!-- <label>USER NAME:</label><br> -->		
				<input type="text" name="user" placeholder="user name" autofocus class="input" autocomplete="off" required><br>
			</div>

			<div id="masuk">
				<!-- <label>PASSWORD:</label><br> -->
				<input type="password" name="password" placeholder="password" class="input" autocomplete="off" required><br>
			</div>


				<input type="checkbox" name="remember">
				<label>Remember me</label>
		
			
			<div class="tombol">
				<input type="submit" value="login" class="input">
			</div>
			
		</form>
	</div>
	</div>
</body>
</html>