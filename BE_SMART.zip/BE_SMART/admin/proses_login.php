  <?php
$koneksi=new mysqli("localhost","root","","smart");

$var1 = $_POST['user'];
$var2 = $_POST['password'];

// header("Location:Utama.php")

$sql = $koneksi->query("SELECT * FROM admin where user='$var1' and password='$var2'");
// mysqli_num_rows($sql);
$cek = $sql->num_rows;

if ($cek == 1) {
	session_start();
	$_SESSION['admi'] = $sql->fetch_assoc();
	header("Location:index_admin.php");
}else{
	echo "Gagal Masuk";
	header("Location: login_admin.php");
	} 
 ?>
