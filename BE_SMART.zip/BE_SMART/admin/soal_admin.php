<?php 
	$koneksi= mysqli_connect('localhost','root','','smart');

	if (isset($_POST['submit'])) {

		$soal	= htmlspecialchars($_POST['soal']);
		$a   	= htmlspecialchars($_POST['a']);
		$b   	= htmlspecialchars($_POST['b']);
		$c   	= htmlspecialchars($_POST['c']);
		$d   	= htmlspecialchars($_POST['d']);
		$jwb 	= htmlspecialchars($_POST['jwb']);

		
		$query="INSERT INTO soal VALUES(NULL,'$soal','$a','$b','$c','$d','$jwb')";
		mysqli_query($koneksi,$query);
		if (mysqli_affected_rows($koneksi)) {
			echo "
					<script>
						alert('DATA BERHASIL DITAMBAH');
						document.location.href='soal_admin.php';
					</script>
				";
		}else{
			echo "
					<script>
						alert('DATA BERHASIL DITAMBAH');
						document.location.href='soal_admin.php';
					</script>
				";''
		}

	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>soal</title>
	<link rel="stylesheet" type="text/css" href="Style_a.css">
</head>
<body>
	<div id="menu">
			<ul class="ul">
				<li class="menu">
					<a href="index_admin.php">Admin</a>
				</li>
				<li class="menu">
					<a href="soal_admin.php"> Buat Soal</a>
				</li>
				<li class="menu">
					<a href="ubah_soal.php"> update Soal</a>
				</li>
				<li class="menu">
					<a href="materi_admin.php"> Materi</a>
				</li>
				<li class="menu">
					<a href="ubah_materi.php"> Update Materi </a>
				</li>
			</ul>
	</div>
	<div id="header">
		<a href="logout.php">logout</a>
	</div>

	
	
	<div id="soal">
		<form action="" method="post" class="soal">
			<div class="tabel">
				<textarea type="text" name="soal" placeholder="soal" required autofocus autocomplete="off"></textarea><br>
			</div>

			<div class="tabel">
				<input type="text" name="a" placeholder="jawaban a" class="input" required autocomplete="off"><br>
			</div>
			
			<div class="tabel">
				<input type="text" name="b" placeholder="jawaban b" class="input" required autocomplete="off"><br>
			</div>
				
			<div class="tabel">
				<input type="text" name="c" placeholder="jawaban c" class="input" required autocomplete="off"><br>
			</div>	
			
			<div class="tabel">
				<input type="text" name="d" placeholder="jawaban d" class="input" required autocomplete="off"><br>
			</div>	
			
			<div class="tabel">
				<ul class="ul">
					<li class="li">
						<label>a</label>
						<input type="radio" name="jwb" value="a" required>
					</li>
					<li class="li">
						<label>b</label>
						<input type="radio" name="jwb" value="b" required>
					</li>
					<li class="li">
						<label>c</label>
						<input type="radio" name="jwb" value="c" required>
					</li>
					<li class="li">
						<label>d</label>
						<input type="radio" name="jwb" value="d" required>
					</li>
				</ul>
				
			</div>

			<div class="tombol">
				<input type="submit" name="submit" value="masukan">
			</div>
		</form>
	</div>

</body>
</html>